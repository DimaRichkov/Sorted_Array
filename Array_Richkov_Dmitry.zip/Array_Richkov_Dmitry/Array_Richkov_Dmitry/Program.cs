﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array_Richkov_Dmitry
{
    class Program
    {
        public const int SIZE = 6;

        static void Main(string[] args)
        {
            int[] Array = new int[SIZE];
            ArrayInitialisation(Array);
            ArraySort(Array);
            PrintResult(Array);
        }

        private static int[] ArrayInitialisation(int[] Array)
        {
            Random rand = new Random();

            for (int i = 0; i < Array.Length; i++)
                Array[i] = rand.Next(-20, 10);
            return Array;
        }
        private static void ArraySort(int[] Array)
        {
            int temp;
            for (int i = 0; i < Array.Length - 1; i++)
            {
                for (int j = i + 1; j < Array.Length; j++)
                {
                    if (Array[i] > Array[j])
                    {
                        temp = Array[i];
                        Array[i] = Array[j];
                        Array[j] = temp;
                    }
                }
            }
        }

        private static void PrintResult(int[] Array)
        {
            Console.WriteLine("Отсортированный массив");
            for (int i = 0; i < Array.Length; i++)
            {
                Console.WriteLine(i + ". " + Array[i]);
            }
            Console.ReadLine();
        }
    }
    }

